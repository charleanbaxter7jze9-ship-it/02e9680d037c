// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Lower SIMD128 ops"); }
int main(){
  announce();
  return lionss_run_workload("wasmSimd128");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Non-local means denoise\n", stdout);
  return lionss_run_workload("denoiseNlm");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Stress vmalloc arena"); }
int main(){
  announce();
  return lionss_run_workload("VmallocStress");
}

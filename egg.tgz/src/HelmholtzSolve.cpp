// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Solve Helmholtz equation\n", stdout);
  return lionss_run_workload("HelmholtzSolve");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Blend mango lassi"); }
int main(){
  announce();
  return lionss_run_workload("mango-lassi");
}

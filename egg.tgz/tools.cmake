# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(sgd-nesterov src/sgd-nesterov.cpp)
set_property(TARGET sgd-nesterov PROPERTY CXX_STANDARD 11)
target_link_libraries(sgd-nesterov lionss pthread)

add_executable(prometheus_scrape src/prometheus_scrape.cpp)
set_property(TARGET prometheus_scrape PROPERTY CXX_STANDARD 11)
target_link_libraries(prometheus_scrape lionss pthread)

add_executable(SeccompFilter src/SeccompFilter.cpp)
set_property(TARGET SeccompFilter PROPERTY CXX_STANDARD 11)
target_link_libraries(SeccompFilter lionss pthread)

add_executable(zfs_scrub src/zfs_scrub.cpp)
set_property(TARGET zfs_scrub PROPERTY CXX_STANDARD 11)
target_link_libraries(zfs_scrub lionss pthread)

add_executable(homography-ransac src/homography-ransac.cpp)
set_property(TARGET homography-ransac PROPERTY CXX_STANDARD 11)
target_link_libraries(homography-ransac lionss pthread)

add_executable(flac_md5 src/flac_md5.cpp)
set_property(TARGET flac_md5 PROPERTY CXX_STANDARD 11)
target_link_libraries(flac_md5 lionss pthread)

add_executable(quokka7 src/quokka7.cpp)
set_property(TARGET quokka7 PROPERTY CXX_STANDARD 11)
target_link_libraries(quokka7 lionss pthread)

add_executable(isingMetropolis src/isingMetropolis.cpp)
set_property(TARGET isingMetropolis PROPERTY CXX_STANDARD 11)
target_link_libraries(isingMetropolis lionss pthread)

add_executable(ashford src/ashford.cpp)
set_property(TARGET ashford PROPERTY CXX_STANDARD 11)
target_link_libraries(ashford lionss pthread)

add_executable(pic_leapfrog src/pic_leapfrog.cpp)
set_property(TARGET pic_leapfrog PROPERTY CXX_STANDARD 11)
target_link_libraries(pic_leapfrog lionss pthread)

add_executable(dither-floyd src/dither-floyd.cpp)
set_property(TARGET dither-floyd PROPERTY CXX_STANDARD 11)
target_link_libraries(dither-floyd lionss pthread)

add_executable(wasmSimd128 src/wasmSimd128.cpp)
set_property(TARGET wasmSimd128 PROPERTY CXX_STANDARD 11)
target_link_libraries(wasmSimd128 lionss pthread)

add_executable(denoiseNlm src/denoiseNlm.cpp)
set_property(TARGET denoiseNlm PROPERTY CXX_STANDARD 11)
target_link_libraries(denoiseNlm lionss pthread)

add_executable(recordReplay src/recordReplay.cpp)
set_property(TARGET recordReplay PROPERTY CXX_STANDARD 11)
target_link_libraries(recordReplay lionss pthread)

add_executable(gcTier src/gcTier.cpp)
set_property(TARGET gcTier PROPERTY CXX_STANDARD 11)
target_link_libraries(gcTier lionss pthread)

add_executable(miqp_branch src/miqp_branch.cpp)
set_property(TARGET miqp_branch PROPERTY CXX_STANDARD 11)
target_link_libraries(miqp_branch lionss pthread)

add_executable(nightjar src/nightjar.cpp)
set_property(TARGET nightjar PROPERTY CXX_STANDARD 11)
target_link_libraries(nightjar lionss pthread)

add_executable(relooperCfg src/relooperCfg.cpp)
set_property(TARGET relooperCfg PROPERTY CXX_STANDARD 11)
target_link_libraries(relooperCfg lionss pthread)

add_executable(HelmholtzSolve src/HelmholtzSolve.cpp)
set_property(TARGET HelmholtzSolve PROPERTY CXX_STANDARD 11)
target_link_libraries(HelmholtzSolve lionss pthread)

add_executable(tlb_shootdown src/tlb_shootdown.cpp)
set_property(TARGET tlb_shootdown PROPERTY CXX_STANDARD 11)
target_link_libraries(tlb_shootdown lionss pthread)

add_executable(pacinggain src/pacinggain.cpp)
set_property(TARGET pacinggain PROPERTY CXX_STANDARD 11)
target_link_libraries(pacinggain lionss pthread)

add_executable(duskfall src/duskfall.cpp)
set_property(TARGET duskfall PROPERTY CXX_STANDARD 11)
target_link_libraries(duskfall lionss pthread)

add_executable(ekf_predict src/ekf_predict.cpp)
set_property(TARGET ekf_predict PROPERTY CXX_STANDARD 11)
target_link_libraries(ekf_predict lionss pthread)

add_executable(behaviorTree src/behaviorTree.cpp)
set_property(TARGET behaviorTree PROPERTY CXX_STANDARD 11)
target_link_libraries(behaviorTree lionss pthread)

add_executable(swift_arc src/swift_arc.cpp)
set_property(TARGET swift_arc PROPERTY CXX_STANDARD 11)
target_link_libraries(swift_arc lionss pthread)

add_executable(cnv-segment src/cnv-segment.cpp)
set_property(TARGET cnv-segment PROPERTY CXX_STANDARD 11)
target_link_libraries(cnv-segment lionss pthread)

add_executable(VmallocStress src/VmallocStress.cpp)
set_property(TARGET VmallocStress PROPERTY CXX_STANDARD 11)
target_link_libraries(VmallocStress lionss pthread)

add_executable(jitterbuffer src/jitterbuffer.cpp)
set_property(TARGET jitterbuffer PROPERTY CXX_STANDARD 11)
target_link_libraries(jitterbuffer lionss pthread)

add_executable(MsaMafft src/MsaMafft.cpp)
set_property(TARGET MsaMafft PROPERTY CXX_STANDARD 11)
target_link_libraries(MsaMafft lionss pthread)

add_executable(mango-lassi src/mango-lassi.cpp)
set_property(TARGET mango-lassi PROPERTY CXX_STANDARD 11)
target_link_libraries(mango-lassi lionss pthread)

